Apagar este frase e escrever outra aqui

Esse arquivo é de instruções 