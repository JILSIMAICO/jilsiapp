#!/bin/bash
cp -R /home/ec2-user/app/* /var/www/html/   